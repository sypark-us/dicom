# About Test Dicom Files

This includes the test dicom files, as required for some test scenarios.

#### **IsamData_162630.dcm**
This Dicom file is for patient 162630 with studydate "20181209".  
This file is specifically generated to represent the scenario where AI can't successfully analyse the findings and providing the notification code to the viewer; (i.e.  111245 in this case)  

This information is encoded as TID1500 as (365853002, SNOMED, "Imaging finding ").  
This information is represented by the property "m_viewerNotificationCode" in Isam datamodel.  
The possible values for this entry are:  
- (111241, DCM, “All algorithms succeeded; without findings”)
- (111245, DCM, “No algorithms succeeded; without findings”)
- (111243, DCM, “Not all algorithms succeeded; without findings”)

