# List of all Dev JSON files
These file are used by dev team and also as Mock Data for some automated tests) 
The description of each files and there uses are explained here:
 
1. **IsamData.json**  
This test file is used in following unit testing:    
    - isam-dataservice library  
    - server side IsamExportService unit testing.

2. **IsamData_isamDataModel.json**  
This file is used for the client side unit tests in isam-datamodel library

- Study1:
    - has the specific m_studyIdentifier, m_referencedInstances and m_predecessorDocuments properties which are used in the unit test cases of the isam-dataset.spec.ts and isam-study-data.spec.ts files
- Study2:
    - has 10 lesions which has different classifications which is used in the test cases of the isam-lesion.spec.ts file
- Study3:
    - has 10 lesions with different classifications as compared to lesions of study 2 which is the immediate prior study of study3
   
3. **IsamData-isam-ui.json**  
This test file is used in following client side unit testing:    
    - isam-ui library (for testing various scenario on tracking chart)  

4. **IsamData_missingRandomDataPoints.json**  
This test file is used by the tracking chart logic to emulate the various missing data points scenarios.  

- Lesion1:   
    - has correct dimensions on current study  
    - has unknown linear and volume measurements on immediate prior study  

- Lesion3:  
    - has unknown volume but valid linear measurements on current study  

- Lesion4:  
    - has unknown linear but correct volume measurements on current study 

5. **IsamData-TCGA-DD-A4NK.json**  
This is the first/basic JSON file used by devs, for general purpose.  