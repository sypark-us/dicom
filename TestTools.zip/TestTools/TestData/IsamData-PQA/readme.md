# List of all PQA JSON files (associated with DICOM data)
# Liver

1. The IsamData.json files from "CTLIVER-P352" folder are associated with DICOM data:
	- PatientName=CTLIVER, P352
	- PatientID=TCGA-DD-A4NL

2. The IsamData.json files from "CTLIVER-P353" folder are associated with DICOM data:
	- PatientName=CTLIVER, P353;
	- PatientID=TCGA-DD-A4NK

3. The IsamData.json files from "DataX" folders are associated with DICOM data:
	- PatientName=870364, TEST CARD93-96;
    - PatientID=162630
The DataX files have only single phase (Portal Venous)

4. The IsamData.json files under "Rochester-##########" folders are associated with the PatientID given by ##########, housed on 10.4.36.25
-------------------------------------------


1. Data1 > FindingsOnAllStudies
    - Data1.1:
        - IsamData_Data1.1.1.json > 4LesionsSequential on images 18, 19, 20, 21
        - IsamData_Data1.1.2.json > findings on all studies

    - Data1.2:
        - IsamData_Data1.2 > Hazard3_CurrentLesion1EmptyVolume (INVALID SCENARIO TEST)

2. Data2 > FindingsOnCurrentP2P3-NoFindingsOnP1
		- IsamData_Data2.json > FindingsOnCurrentP2P3-NoFindingsOnP1

3. Data3 > FindingsOnCurrentOnly
		- IsamData_Data3.json > FindingsOnCurrentOnly

4. Data4 > NoFindingsOnCurrentP2-FindingsOnP1
		- IsamData_Data4.json > NoFindingsOnCurrentP2-FindingsOnP1

5. Data5 > NoFindingsOnCurrentP1P2
		- IsamData_Data5.json > NoFindingsOnCurrentP1P2

6. Data6 > FindingsOnCurrentP1P2-Lesion1NewInCurrent
	- Data6.1:
		- IsamData_Data6.1.json > FindingsOnCurrentP1P2-3LesionsHCC_1LesionIndeterminate
	- Data6.2:
		- IsamData_Data6.2.json > FindingsOnCurrentP1P2-Lesion1NewInCurrent

7. Data7 > DifferentMeasurementUnits
	- Data7.1:
		- IsamData_Data7.1.json > DifferentMeasUnitsCurrent-P1
	- Data7.2:
        - IsamData_Data7.2.json > Haz1_DiffMeasUnits-CurrentLesion3VolM3-CurrentLesion4LinearMeasMicroMeter (INVALID SCENARIO TEST)
	- Data7.3:
        - IsamData_Data7.3.json > Haz2_DiffMeasUnits-CurrentLesion3VolInM3-P1Lesion1LinearMeasMicrometer (INVALID SCENARIO TEST)

8. Data9 > MultipleLesionsOnSameImage-Lesion1.1NEW
	- Data9.1:
		- IsamData_Data9.1.json	> MultipleLesionsOnSameImage-Lesion11NEW
	- Data9.2:
        - IsamData_Data9.2.json > 3CouinaudSegsCurrentLesion11_EmptyCouinaudSegCurrentLesion2_WrongCouinaudSegRID53CurrentLesion3 (INVALID SCENARIO TEST)

9. Data11 > Transformedlesions
	- Data11.1:
		- IsamData_Data11.1.json > L1SuspiciousInCurrent_L1IndeterminateInP1-L5NEWinCurrent
	- Data11.2:
		- IsamData_Data11.2.json > L1SuspCurr_L1UnevalP1_L2HemangiomaCurr_L2UnevalP1_L5NewCurrent


10. Data12 > NEW flag
	- Data12.1:
		- IsamData_Data12.1.json > AllAnalyzed-L1inCurrentAndP1

	- Data12.2:
		- IsamData_Data12.2.json > CurrentP2P3Analyzed-P1NotAnalyzed

	- Data12.3:
		- IsamData_Data12.3.json > AnalyzedAndFindingsOnCurrentOnly

11. Data13 > HounsfieldUnit_Enhancement_ProbabilityScore_KeyCharacteristics
	- Data13.1:
		- IsamData_Data13.1.json > 6Lesions_HounsfieldUnit_Enhancement_ProbabilityScore_KeyCharacteristics_AllLesionLaunch

            - Lesion1:
				- with all valid measurements
				- HU(STD DEV and Mean)
                - Key Char,
				- Hyper Enhancement(Portal) information
				- No Couinaud Segments information.
            - Lesion2:
				- with all valid measurements
				- HU (STD DEV and Mean)
				- 2 Couinaud Segments information
				- No info about Key Char, Enhancement
			- Lesion3:
				- with all valid measurements
                - Hypo Enhancement(Portal)
                - No HU(STD Dev), Couinaud Segments, and Key Char information
            - Lesion4:
				- with all valid measurements
				- Hypo Enhancement(Portal)
                - Single Couinaud Segments
				- No HU(Mean), and Key Char information
            - Lesion5:
				- with all valid measurements
				- 2 Couinaud Segments information
				- No HU(STD DEV and Mean), Key Char, and Enhancement
			- Lesion6:
				- with all valid measurements
				- No HU(STD DEV and Mean), Couinaud Segments information, Key Char, and Enhancement

12. Data14 > Unknown_Classification
	-Data14.1:
		- IsamData_Data14.1.json > Unknown_Classification
			- For current study,finding 1,2,5,6 are with Unknown Classifications.Finding 3 has HCC Classification.Finding 4 has Other Benign classification
            - Finding 4 has Unknown Classification on Prior P1
			- finding 5 has Other Benign on Prior p1

13. CTLIVER-P352
	- Data1_P352 > HounsfieldUnit_Enhancement_ProbabilityScore_KeyCharacteristics
        - IsamData_Data1_P352.json
            > 4Lesions_HounsfieldUnit_Enhancement_ProbabilityScore_KeyCharacteristics_AllLesionLaunch
            > All lesions and bodyparts for all studies has valid volume measurement with correct phase values.
			(except lesion3 from current study "20010711" which do not have volume property)

            - Lesion1:
				- Information present for volume
				- 2 couinuad segments
				- 1 primary classifn, 3 other classifn
                - 2 key char.
				- **Portal Venous:**
                    - Long and short axis,  HU(Mean and STD DEV), Hyper Enhancement
				- **Arterial Phase:**
                    - No info about Long and short axis
                    - Info present for HU(Mean and STD DEV), Iso Enhancement
                - **Delayed Phase:**
                    - No info about Long and short axis
                    - Info present for HU(Mean and STD DEV), Hypo Enhancement
                - **Precontrast Phase:**
                    - No info about Long and short axis
                    - Info present for HU(Mean and STD DEV)
            - Lesion2:
				- Information present for volume
				- 1 couinuad segments
				- primary classifn, 1 other classifn
				- 2 key char.
                - **Portal Venous:**
					- Long and short axis, HU(Mean and STD DEV).
                    - No info about Enhancement
                - **Arterial Phase:**
                    - No info about Long and short axis, Enhancement
                    - Info present for HU(Mean and STD DEV)
                - **Delayed Phase:**
                    - No info about Long and short axis, HU(Mean and STD DEV), Enhancement
                - **Precontrast Phase:**
                    - No info about Long and short axis, HU(STD DEV)
                    - Info present for HU(Mean)
            - Lesion3:
				- No Information present for volume and couinuad segments.
				- Info present for primary classifn, 0 other Classifn
				- 2 key char.
                - **Portal Venous:**
                    - Info present for HU(Mean), Hypo Enhancement
                     No info about Long and short axis, HU(STD DEV)
                - **Arterial Phase:**
                    - Info present for Long and short axis, HU(Mean and STD DEV), Hypo Enhancement
                - **Delayed Phase:**
                    - Info present for HU(STD DEV), Hypo Enhancement
                    - No info about Long and short axis, HU(Mean)
                - **Precontrast Phase:**
                    - No info about Long and short axis, HU(Mean and STD DEV)
            - Lesion4:
				- Information present for volume
				- 2 couinuad segments
				- 'Indeterminate' primary classifn, 2 other classifn
				- 2 key char.
                - **Portal Venous:**
                    - No info about Long and short axis, Enhancement
                    - Info present for HU(Mean and STD DEV)
                - **Arterial Phase:**
                    - No info about Long and short axis, Enhancement
                    - Info present for HU(Mean and STD DEV)
                - **Delayed Phase:**
                    - Info present about long and short axis, HU(Mean and STD DEV)
                    - No info about Enhancement
                - **Precontrast Phase:**
                    - No info about Long and short axis
                    - Info present for HU(Mean and STD DEV)

	- Data2_P352 > Jump To Linked Scrolling
		- IsamData_Data2_P352.json
			- Finding 1, 2 and 3 are present on current and priors.
			- Finding3 do not have contours on 1 of the 4 series[phases] in the current study i.e it does not have contours on series 5 Arterial phase. Will have contours on rest of the series[phases]. Will have contours on all phases of prior.
			- Finding4 is present on current but not in prior.
			- Finding5 present in prior but not in current.
			- Finding6 is present on Portal, Arterial and Delayed series but not present of Unenhanced series of current study.
			- Core contours on following image/slice:
				- Finding 1: portal(with axial measurements) image 20, arterial image 18, delayed image 19, unenhanced image 1.
				- Finding 3: portal(with axial measurements) image 18, delayed image 19, unenhanced image 3.
				- Fidning 6: portal(with axial measurements) image 30, arterial image 28, delayed image 29.
			- HU vlalues w.r.t. Portal Venous Phase:
				- Finding1 has HU Mean and STD values available in the portal venous phase
				- Finding2 has only HU Mean value in portal venous phase
				- Finding3 do not have HU Mean but have STD value available in the portal venous phase
				- Finding4 do not have HU Mean and STD values in the portal venous phase but has HU values in Other Phases.

	- Data3_P352 > Unknown_Classification
        - IsamData_Data3_P352.json
			- For current study,finding 1,2,3 are with Unknown Classification.Finding4 has HCC Classification
			- Priors do not have Unknown classifications

14. CTLIVER-P353
	- IsamData-19990917_combined_referenceALL4Priors.json
		- Used to test the current study with 4 prior studies defined by "m_referencedInstances" in latest 19990917 study
		- Includes 6 lesions in current study 19990917, 1 lesion(id=23) in 19990430, 1 lesion (id=24) in 19980530, 7 lesion in 19980326, 1 lesion (id=25) in 19970122
		- Contains phase information for all the current and prior studies
		- Lesion 43 has contours in Portal Venous phase on current study 19990917, and in Arterial Phase on prior study 19980326

15. Rochester-997755331
	- IsamData-19981119.json
		- enhancement phases: Unenhanced\Arterial\PortalVenous\Delayed
		- Contains 3 lesions with values populated for Couinaud segments, Key characteristics, and Enhancement
		- Lesions are determined by crosshairs, but not contours.
	- IsamData-20000709.json
		- enhancement phases: PortalVenous\Delayed
		- Contains 2 lesions with values populated for Couinaud segments, Key characteristics, and Enhancement
		- Lesions are determined by crosshairs, but not contours.
	- IsamData-20001105.json
		- enhancement phases: Unenhanced\Arterial\PortalVenous
		- Contains 2 lesions with values populated for Couinaud segments, Key characteristics, and Enhancement
        - Lesions are determined by crosshairs, but not contours.

16. Rochester-2059255685
	- IsamData-20090406.json
		- enhancement phases: Unenhanced\Arterial\PortalVenous\Delayed
		- Contains 5 lesions with values populated for Couinaud segments, Key characteristics, and Enhancement
		- Lesions are determined by crosshairs, but not contours.

17. Rochester-7624402760
	- IsamData-19980717.json
		- enhancement phases: Arterial\PortalVenous
		- Contains 4 lesions with values populated for Couinaud segments, Key characteristics, and Enhancement
		- Lesions are determined by crosshairs, but not contours.
	- IsamData-19980722.json
		- enhancement phases: PortalVenous
		- Contains 1 lesion with values populated for Couinaud segments, Key characteristics, and Enhancement
		- Lesions are determined by crosshairs, but not contours.

############################################################################################################
# Prostate


1. The IsamData.json files from under "DataP1", "DataP5" folder are associated with DICOM data:
    - Patient Name = PROSTATEX-0020^^^^,
    - Patient ID = ProstateX-0020

2. The IsamData.json and .dcm files from under "DataP2", "DataP3", "DataP4", folder are associated with DICOM data:
    - Patient Name= ProstateX-0018,
    - Patient ID= ProstateX-0018

3. The IsamData.json and .dcm files from under "DataP6", folder are associated with DICOM data:
    - Patient Name= 779456^^^^",
    - Patient ID= 7794563016

-------------------------------------------

0. DataP0 > Rochester Original AI generated SR(JSON).
    - 1385946665.json
    - 2586065443.json
    - 2809397225.json
    - ProstateX-0018.json
    - ProstateX-0020.json

1. DataP1 > Prostate Length, Width and Volume
    - IsamData_DataP1.1.json > Length_Width_Empty
    - IsamData_DataP1.2.json > Length and Width have supported units i.e "mm"
    - IsamData_DataP1.3.json > Length and Width have unsupported units i.e "m"
    - IsamData_DataP1.4.json > Length,Width and Volume Values are available to display in UI.
    - IsamData_DataP1.5.json > Length,Width and Volume have value as zero("0")

2. DataP2 > Finding length, width, volume, location, PI-RADS score & key characteristics
    - IsamData_DataP2.1.json > This data is used to test story 571 to display valid/invalid values and story 1408 to display Prostate zone values in prostate finding table. Test IDs- AIV-873, AIV-874 and AIV-923
        - Finding 1 has valid values with axial diameter unit as decimeter i.e "dm" and single Prostate zone value
        - Finding 2 has all valid values with blank PIRAD value and Axial Diameter property is missing and more than one Prostate zone values
        - Finding 3 has all valid values with Axial Diameter unit as kg and PIRAD value as RID50322 and multiple Prostate zone values
        - Finding 4 has all valid values with Axial Diameter as decimal value with unit as cm and Prostate zone property is missing
        - Finding 5 has all valid values with unit for Axial Diameter as millimeter i.e "mm"
        - Finding 6 has all valid values with short axis of Axial Diameter as zero("0") with unit as cm

    - IsamData_DataP2.2.json > This data is used to test 577 story to display PiRads value with blank entry in prostate finding table. Test ID- AIV-878
        - Finding 1 should have all values with blank entry for PIRAD value
        - Finding 2 should have PIRAD value as RID50322

    - IsamData_DataP2.3.json > This data is used to test 577 story and 608 story to display valid axial and PiRads values any story 574 to display key characteristics in prostate finding table. Test IDs- AIV-877 and AIV-875
        - Finding 1 has Axial Diameter - 13.1x2.7cm, PI-RADS - 1, key characteristics- RID43356 (Evidence of Involvement of the Left Neurovascular Bundle)
        - Finding 2 has Axial Diameter - 4.8x3.3cm, PI-RADS - 2, key characteristics- RID4736 (Pelvic Adenopathy), RID4736 (Bone Lesion), RID43356 (Left Seminal Extension)
        - Finding 3 has Axial Diameter - 7x2.6cm, PI-RADS - 1

    - IsamData_DataP2.4.json > This data is used to test 608 story to verify missing and unsupported measurement units in prostate finding table. Test IDs- AIV-882
        - Finding 1 has Volume, Long axis, Short axis properties are missing
        - Finding 2 has Volume - 237.45dL, Long axis- 8.5nm, Short axis-4.3m
        - Finding 3 has Volume - 121.0dL, Long axis property is missing, Short axis-41.31cm
        - Finding 4 has Volume property is missing, Long axis- 0cm, Short axis-3.31nm

    - IsamData_DataP2.5.json > This data is used to test 606 story and 946 story to display PiRads with few blank entries. Test IDs- AIV-876 AIV-867 AIV-881
        - Finding 1 has Axial Diameter -  13.1x2.7cm, PI-RADS - 1
        - Finding 2 has Axial Diameter -  8.5x4.3cm, PI-RADS - 5
        - Finding 3 has Axial Diameter -  4.8x3.3cm, PI-RADS - no value
        - Finding 4 has Axial Diameter -  4.8x3.3cm, PI-RADS - no value

    - IsamData_DataP2.6.json > This data is used to test 394 story and 809 story to display PSA Values, Date and PiRads with few blank entries. Test IDs- AIV-912 AIV-932 AIV-909 AIV-911
        - Finding 1 has Axial Diameter -  13.1x2.7cm, PI-RADS - 1
        - Finding 2 has Axial Diameter -  8.5x4.3cm, PI-RADS  - 5
        - Finding 3 has Axial Diameter -  4.8x3.3cm, PI-RADS - no value
        - Finding 4 has Axial Diameter -  4.8x3.3cm, PI-RADS - no value

3. DataP3 > AIViewer Notification
    - IsamData_DataP3.1.dcm > Study rejected message when data can not be processed by analytics
    - IsamData_DataP3.2.dcm > Study rejected message when prostate could not be segmented by the AI.
    - IsamData_DataP3.3_UDI.dcm > Prostate capr-fake-udi UDI with version 1.A
    - IsamData_DataP3.3.json > Prostate capr-fake-udi UDI with version 1.A (On Test data conversion to dcm, dcm file need to be updated with 'Manufacture's model name' value to "IBM Watson Care Advisor for prostate" and 'Unique Device Identifier' value to "capr-fake-udi".

4. DataP4 > Export Segmentation, data with Prostate and Finding contours
    - IsamData_DataP4.1.json > No Prostate + No Finding + No PSA
    - IsamData_DataP4.2.json > Prostate + No Finding
    - IsamData_DataP4.3.json > With prostate segmentation results, 1 Findings present and Warning message private tag
        - Finding is present on ( Series 5 image 6,7,8)
        - Rest all image slice have only prostate contours
        - Warning message - "{header}The safety and effectiveness of Care Advisor for prostate has not been established for: {details}Patients with right-sided heart failure, Patients who have undergone prior prostate surgery; … {footer}Care Advisor for prostate output for these patients/studies/images should not be used."
    - IsamData_DataP4.4.json > With prostate segmentation results and 3 Findings present
       - Finding 1 is present on Inside Prostate Series 5 Image 6,7,8
       - Finding 2 is present on Inside Prostate Series 5 Image 4,5,6
       - Finding 3 is present on Inside Prostate Series 5 Image 9,10,11
    - IsamData_DataP4.5.json >  Prostate + 3 Findings (1 inside, 1 outside, 1 no prostate)
        - Finding 1 is present on Outside prostate Series 5 Image 4,5,6
        - Finding 2 is present on Inside prostate Series 5 Image 6,7,8
        - Finding 3 is present on no prostate Series 5 Image 1,2

5. DataP5 > PSA Value_PSA Date_Volume
    - IsamData_DataP5.1.json > With Multiple PSAValue & PSADate blocks with valid values
    - IsamData_DataP5.2.json > With Multiple PSAValue & PSADate blocks with empty PSADate in one of the blocks
    - IsamData_DataP5.3.json > With valid PSATestDate, PSAValue and volume
    - IsamData_DataP5.4.json > With invalid PSAValue unitcode and blank Volume
    - IsamData_DataP5.5.json > With PSATestDate as Future Date i.e. "20221225035556"
    - IsamData_DataP5.6.json > With PSATestDate as Old Date i.e. "19991231102035"
    - IsamData_DataP5.7.json > With PSAValue and Volume as Zero '0'

6. DataP6 > Data with Prostate and Finding contours
     - IsamData_DataP6.1.json >  With prostate segmentation results, 1 Findings present
        - Finding 1 has -  only Finding contour(Series 3 image 3,4,5,6), With Length 0.64 cm ,Width 0.46 cm and volume 11 mL.