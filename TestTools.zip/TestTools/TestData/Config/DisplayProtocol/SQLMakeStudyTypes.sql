/***********************************************************************************
//  +==============================================================================+
//  | Licensed Materials - Property of IBM                                         |
//  | (C) Copyright IBM Corp. 2018,2022                                            |
//  | US Government Users Restricted Rights- Use, duplication or disclosure        |
//  | restricted by GSA ADP Schedule Contract with IBM Corp.                       |
//  +==============================================================================+
***********************************************************************************/

USE [IRWSDB]
GO

DECLARE @DomainID AS NVARCHAR(32); /* Add new StudyTypes to this Domain */
SET @DomainID = 'SuperAdminGroup';

IF OBJECT_ID(N'dbo.HPTemp', N'U') is not NULL
DROP TABLE [dbo].[HPTemp]
;
IF OBJECT_ID(N'dbo.HPTemp1', N'U') is not NULL
DROP TABLE [dbo].[HPTemp1]
;
IF OBJECT_ID(N'dbo.HPTemp2', N'U') is not NULL
DROP TABLE [dbo].[HPTemp2]
;
/*
Make more Study Types and Series Types
 Create temp tables which are just like our original table
*/
CREATE TABLE [dbo].[HPTemp](
    [StudyTypeUid] [int] NOT NULL,
    [StudyTypeName] [nvarchar](32) UNIQUE NOT NULL,
    [StudyTypeXml] [xml] NOT NULL,
    [CreationType] [tinyint] NOT NULL,
    [AccessType] [tinyint] NOT NULL,
    [DomainID] [nvarchar](32),
    [CreatedBy] [nvarchar](32),
    [CreationTime] [datetime],
    [LastModifiedTime] [datetime]
);
CREATE TABLE [dbo].[HPTemp1](
    [StudyTypeUid] [int] NOT NULL,
    [StudyTypeName] [nvarchar](32) UNIQUE NOT NULL,
    [StudyTypeXml] [xml] NOT NULL,
    [CreationType] [tinyint] NOT NULL,
    [AccessType] [tinyint] NOT NULL,
    [DomainID] [nvarchar](32),
    [CreatedBy] [nvarchar](32),
    [CreationTime] [datetime],
    [LastModifiedTime] [datetime]
);
CREATE TABLE [dbo].[HPTemp2](
    [StudyTypeUid] [int] NOT NULL,
    [StudyTypeName] [nvarchar](32) UNIQUE NOT NULL,
    [StudyTypeXml] [xml] NOT NULL,
    [CreationType] [tinyint] NOT NULL,
    [AccessType] [tinyint] NOT NULL,
    [DomainID] [nvarchar](32),
    [CreatedBy] [nvarchar](32),
    [CreationTime] [datetime],
    [LastModifiedTime] [datetime]
);

SET IDENTITY_INSERT [HangingProtocolStudyType] ON;

/*
 Select however many DEV-* records we have from the real table and put them into a temporary location
   Reuse them to seed N new records into the original table
*/

INSERT INTO [HPTemp2] (StudyTypeUid, StudyTypeName, StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
 SELECT StudyTypeUid, StudyTypeName, StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime from [HangingProtocolStudyType]
 where ([DomainID] = @DomainID) and (StudyTypeName like 'DEV-%');
 select * from [HPTemp2]
/*
 Set the number of new records to add
*/
DECLARE @RecordsToAdd INT = 200;
DECLARE @RecordCount INT = 0;

WHILE @RecordCount <= @RecordsToAdd
BEGIN

INSERT INTO [HPTemp] (StudyTypeUid, StudyTypeName, StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
 SELECT StudyTypeUid, StudyTypeName, StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime from [HPTemp2];

/*
 Now update the ID Name and XML for each of these records with a new name
*/
    DECLARE @RunningTotal INT = 0;
    DECLARE @RowCnt INT = 0;
    SELECT @RowCnt = COUNT(0) from [HPTemp]

    DELETE TOP(1) FROM [HPTemp1];
    WHILE @RunningTotal <= @RowCnt AND @RecordCount <= @RecordsToAdd
    BEGIN

        SET @RecordCount += 1;
        SET @RunningTotal += 1;
/*
 Determine the next ID to be added
*/
        DECLARE @NextID INT;
        SELECT @NextID = max([StudyTypeUid]) FROM [HangingProtocolStudyType];
        SET @NextID += 1
        PRINT @NextID;
/*
 Grabe the first record in the table to work on
*/

        INSERT INTO [HPTemp1] (StudyTypeUid, StudyTypeName, StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
        SELECT TOP(1) StudyTypeUid, StudyTypeName, StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime from [HPTemp]
/*
 Update the Name and ID in the Record and in the XML. New name is of the formt <Original Name>-N where N is the ID
*/
        DECLARE @Name [nvarchar](32);
        SELECT @Name = [StudyTypeName] from [HPTemp1];
/*
  Try to ensure the repeated running of this script doesn't completely mess up the names - strip everything
  to the right of the :. Allow for :xxx to be appended AND fit in 32 characters
*/      IF (LEN(@Name) >= 28)
            BEGIN
            SET @Name = LEFT(@Name,28)
            END
        ;
        IF PATINDEX('%_:%', @Name) != 0
            BEGIN
                SET @Name = LEFT(@Name,PATINDEX('%_:%', @Name))
            END
        ;
        SET @Name = CONCAT(@Name, ':')
        SET @Name = CONCAT(@Name, @NextID);

        UPDATE [HPTemp1] SET StudyTypeName = @Name;
        UPDATE [HPTemp1] SET StudyTypeUid = @NextID;
        UPDATE [HPTemp1] SET StudyTypeXml.modify('replace value of (/StudyType/@Name)[1] with sql:variable("@Name")');
        UPDATE [HPTemp1] SET StudyTypeXml.modify('replace value of (/StudyType/@ID)[1] with sql:variable("@NextID")');
/*
 Save our record back to the original DB table
*/
        INSERT INTO [HangingProtocolStudyType] (StudyTypeUid, StudyTypeName, StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
        SELECT StudyTypeUid, StudyTypeName, StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime from [HPTemp1];
/*
 Remove the record we just started with
*/
        DELETE TOP(1) FROM [HPTemp];
/*
 Empty our working table
*/
        DELETE TOP(1) FROM [HPTemp1];
    END
END
SET IDENTITY_INSERT [HangingProtocolStudyType] OFF;

SELECT * from [HangingProtocolStudyType];

/*
 Cleanup working tables
*/
DROP TABLE [dbo].[HPTemp];
DROP TABLE [dbo].[HPTemp1];
DROP TABLE [dbo].[HPTemp2];
