/***********************************************************************************
//  +==============================================================================+
//  | Licensed Materials - Property of IBM                                         |
//  | (C) Copyright IBM Corp. 2018,2022                                            |
//  | US Government Users Restricted Rights- Use, duplication or disclosure        |
//  | restricted by GSA ADP Schedule Contract with IBM Corp.                       |
//  +==============================================================================+
***********************************************************************************/

USE [IRWSDB]
GO
/* Procedure to add a coordinated set of HP, Study Types, Series Types and Step to a DB. Three parameters
   are required.
   1) 'prefix' is string applied to each usage object Name in the data set. It is adjusted n the DB record in in corresponding XML.
   2) 'domainID' where the records are to be created
   3) 'userID' is the name of the user for which the records are made

   Calls to this stored procedure may be made after it has been created.
 */
IF OBJECT_ID('CreateHangingProtocolDataSet', 'p') IS NOT NULL
   DROP PROCEDURE dbo.CreateHangingProtocolDataSet
GO
CREATE PROCEDURE dbo.CreateHangingProtocolDataSet @prefix nvarchar(10), @DomainID nvarchar(32), @UserID nvarchar(32), @CreationType int, @AccessType int
AS
BEGIN
    /*
    CreationType is User Defined or Built-In
    AccessType is ViewProtected, Editable, ReadOnly
    See the tables  HangingProtocolItemCreationType and HangingProtocolItemAccessType
    */

    /* THis is the copy from InitData.sql */
    /*1 = CT_LiverMultiPhase_Study*/
    DECLARE @1FromDBName AS NVARCHAR(32) = @prefix + 'CT_LiverMultiPhase_Study'
    DECLARE @1FromDBXML AS XML = '<StudyType  ID="1" Name="' + @prefix + 'CT_LiverMultiPhase_Study" Description="Care Advisor Liver CT Multi Phase">
          <FilterRadiology>attr(0008,0061/*modalityInStudy*/)="CT"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Radiology" RelOP="NA">attr(0008,0061/*modalityInStudy*/)="SR"</Requires>
              <Requires RuleType="Radiology" RelOP="And">contains(translate(attr(0008,1030/*studyDescription*/), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "liver")</Requires>
              <Requires RuleType="Series" RelOP="And">' + @prefix + 'LiverArterialPhase</Requires>
              <Requires RuleType="Series" RelOP="And">' + @prefix + 'LiverVenousPhase</Requires>
            </Rule>
          </Rules>
        </StudyType>'

    /*2 = CT_LiverSinglePhase_Study*/
    DECLARE @2FromDBName AS NVARCHAR(32) = @prefix + 'CT_LiverSinglePhase_Study'
    DECLARE @2FromDBXML AS XML = '<StudyType ID="2" Name="' + @prefix + 'CT_LiverSinglePhase_Study" Description="Care Advisor Liver CT Single Phase">
          <FilterRadiology>attr(0008,0061/*modalityInStudy*/)="CT"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Radiology" RelOP="NA">attr(0008,0061/*modalityInStudy*/)="SR"</Requires>
              <Requires RuleType="Radiology" RelOP="And">contains(translate(attr(0008,1030/*studyDescription*/), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "liver")</Requires>
              <Requires RuleType="Series" RelOP="And">' + @prefix + 'LiverVenousPhase</Requires>
            </Rule>
          </Rules>
        </StudyType>'

    /*3 = MR_Prostate_CAPR_Study*/
    DECLARE @3FromDBName AS NVARCHAR(32) = @prefix + 'MR_Prostate_CAPR_Study'
    DECLARE @3FromDBXML AS XML = '<StudyType ID="3" Name="' + @prefix + 'MR_Prostate_CAPR_Study" Description="Care Advisor Prostate MR">
          <FilterRadiology>attr(0008,0061/*modalityInStudy*/)="MR"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Radiology" RelOP="NA">attr(0008,0061/*modalityInStudy*/)="SR"</Requires>
              <Requires RuleType="Radiology" RelOP="And">contains(translate(attr(0008,1030/*studyDescription*/), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "prostate")</Requires>
              <Requires RuleType="Series" RelOP="And">' + @prefix + 'ProstateT2Axial</Requires>
            </Rule>
          </Rules>
        </StudyType>'

    /*4 = CT_Liver_VP_Study*/
    DECLARE @4FromDBName AS NVARCHAR(32) = @prefix + 'CT_Liver_VP_Study'
    DECLARE @4FromDBXML AS XML = '<StudyType ID="4" Name="' + @prefix + 'CT_Liver_VP_Study" Description="Care Advisor Liver CT Viewer Protocol">
          <FilterRadiology>attr(0008,0061/*modalityInStudy*/)="CT"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Radiology" RelOP="NA">attr(0008,0061/*modalityInStudy*/)="SR"</Requires>
              <Requires RuleType="Radiology" RelOP="And">contains(translate(attr(0008,1030/*studyDescription*/), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "liver")</Requires>
            </Rule>
          </Rules>
        </StudyType>'

    /*5 = MR_Prostate_VP_Study*/
    DECLARE @5FromDBName AS NVARCHAR(32) = @prefix + 'MR_Prostate_VP_Study'
    DECLARE @5FromDBXML AS XML = '<StudyType ID="5" Name="' + @prefix + 'MR_Prostate_VP_Study" Description="Care Advisor Prostate MR Viewer Protocol">
          <FilterRadiology>attr(0008,0061/*modalityInStudy*/)="MR"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Radiology" RelOP="NA">attr(0008,0061/*modalityInStudy*/)="SR"</Requires>
              <Requires RuleType="Radiology" RelOP="And">contains(translate(attr(0008,1030/*studyDescription*/), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "prostate")</Requires>
            </Rule>
          </Rules>
        </StudyType>'

    /*6 = CR_General_Study*/
    DECLARE @6FromDBName AS NVARCHAR(32) = @prefix + 'CR_General_Study'
    DECLARE @6FromDBXML AS XML = '<StudyType ID="6" Name="' + @prefix + 'CR_General_Study" Description="All CR">
          <FilterRadiology>attr(0008,0061/*modalityInStudy*/)="CR"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Radiology" RelOP="NA">attr(0008,0061/*modalityInStudy*/)="CR"</Requires>
            </Rule>
          </Rules>
        </StudyType>'

    /*7 = CT_General_Study*/
    DECLARE @7FromDBName AS NVARCHAR(32) = @prefix + 'CT_General_Study'
    DECLARE @7FromDBXML AS XML = '<StudyType ID="7" Name="' + @prefix + 'CT_General_Study" Description="All CT">
          <FilterRadiology>attr(0008,0061/*modalityInStudy*/)="CT"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Radiology" RelOP="NA">attr(0008,0061/*modalityInStudy*/)="CT"</Requires>
            </Rule>
          </Rules>
        </StudyType>'

    /*8 = MR_General_Study*/
    DECLARE @8FromDBName AS NVARCHAR(32) = @prefix + 'MR_General_Study'
    DECLARE @8FromDBXML AS XML = '<StudyType ID="8" Name="' + @prefix + 'MR_General_Study" Description="All MR">
          <FilterRadiology>attr(0008,0061/*modalityInStudy*/)="MR"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Radiology" RelOP="NA">attr(0008,0061/*modalityInStudy*/)="MR"</Requires>
            </Rule>
          </Rules>
        </StudyType>'

    /*9 = PT_General_Study*/
    DECLARE @9FromDBName AS NVARCHAR(32) = @prefix + 'PT_General_Study'
    DECLARE @9FromDBXML AS XML = '<StudyType ID="9" Name="' + @prefix + 'PT_General_Study" Description="All PT">
          <FilterRadiology>attr(0008,0061/*modalityInStudy*/)="PT"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Radiology" RelOP="NA">attr(0008,0061/*modalityInStudy*/)="PT"</Requires>
            </Rule>
          </Rules>
        </StudyType>'

    /*10 = XA_General_Study*/
    DECLARE @10FromDBName AS NVARCHAR(32) = @prefix + 'XA_General_Study'
    DECLARE @10FromDBXML AS XML = '<StudyType ID="10" Name="' + @prefix + 'XA_General_Study" Description="All XA">
          <FilterRadiology>attr(0008,0061/*modalityInStudy*/)="XA"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Radiology" RelOP="NA">attr(0008,0061/*modalityInStudy*/)="XA"</Requires>
            </Rule>
          </Rules>
        </StudyType>'

    /*11 = US_General_Study*/
    DECLARE @11FromDBName AS NVARCHAR(32) = @prefix + 'US_General_Study'
    DECLARE @11FromDBXML AS XML = '<StudyType ID="11" Name="' + @prefix + 'US_General_Study" Description="All US">
          <FilterRadiology>attr(0008,0061/*modalityInStudy*/)="US"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Radiology" RelOP="NA">attr(0008,0061/*modalityInStudy*/)="US"</Requires>
            </Rule>
          </Rules>
        </StudyType>'


    /* THis is the copy from InitData.sql */
    /*1 = LiverPreContrastPhase*/
    DECLARE @1SeriesTypeFromDBName AS NVARCHAR(32) = @prefix + 'LiverPreContrastPhase'
    DECLARE @1SeriesTypeFromDBXML AS XML = '<SeriesType ID="1"  Name="' + @prefix + 'LiverPreContrastPhase" Description="Care Advisor Liver CT Pre Contrast">
          <FilterRadiology>attr(0008,0060/*modality*/@series)="CT"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Evaluator" RelOP="NA">equals(Evaluators.SeriesTypeEvaluator.LiverPreContrast(),true)</Requires>
              <Requires RuleType="Radiology" RelOP="Or">(contains(translate(attr(0008,103E/*series description*/@series), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "pre") or contains(translate(attr(0008,103E/*series description*/@series), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "contrast"))</Requires>
            </Rule>
          </Rules>
        </SeriesType>'

    /*2 = LiverArterialPhase*/
    DECLARE @2SeriesTypeFromDBName AS NVARCHAR(32) = @prefix + 'LiverArterialPhase'
    DECLARE @2SeriesTypeFromDBXML AS XML = '<SeriesType ID="2" Name="' + @prefix + 'LiverArterialPhase" Description="Care Advisor Liver CT Arterial">
          <FilterRadiology>attr(0008,0060/*modality*/@series)="CT"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Evaluator" RelOP="NA">equals(Evaluators.SeriesTypeEvaluator.LiverArterialPhase(),true)</Requires>
              <Requires RuleType="Radiology" RelOP="Or">contains(translate(attr(0008,103E/*series description*/@series), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "art")</Requires>
            </Rule>
          </Rules>
        </SeriesType>'

    /*3 = LiverVenousPhase*/
    DECLARE @3SeriesTypeFromDBName AS NVARCHAR(32) = @prefix + 'LiverVenousPhase'
    DECLARE @3SeriesTypeFromDBXML AS XML = '<SeriesType ID="3" Name="' + @prefix + 'LiverVenousPhase" Description="Care Advisor Liver CT Venous">
          <FilterRadiology>attr(0008,0060/*modality*/@series)="CT"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Evaluator" RelOP="NA">equals(Evaluators.SeriesTypeEvaluator.LiverVenousPhase(),true)</Requires>
              <Requires RuleType="Radiology" RelOP="Or">contains(translate(attr(0008,103E/*series description*/@series), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "ven")</Requires>
            </Rule>
          </Rules>
        </SeriesType>'

        /*4 = LiverDelayedPhase*/
    DECLARE @4SeriesTypeFromDBName AS NVARCHAR(32) = @prefix + 'LiverDelayedPhase'
    DECLARE @4SeriesTypeFromDBXML AS XML = '<SeriesType ID="4" Name="' + @prefix + 'LiverDelayedPhase" Description="Care Advisor Liver CT Delayed">
          <FilterRadiology>attr(0008,0060/*modality*/@series)="CT"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Evaluator" RelOP="NA">equals(Evaluators.SeriesTypeEvaluator.LiverDelayedPhase(),true)</Requires>
              <Requires RuleType="Radiology" RelOP="Or">contains(translate(attr(0008,103E/*series description*/@series), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "del")</Requires>
            </Rule>
          </Rules>
        </SeriesType>'

        /*5 = ProstateT2Axial*/
    DECLARE @5SeriesTypeFromDBName AS NVARCHAR(32) = @prefix + 'ProstateT2Axial'
    DECLARE @5SeriesTypeFromDBXML AS XML = '<SeriesType ID="5" Name="' + @prefix + 'ProstateT2Axial" Description="Care Advisor Prostate MR T2 Axial">
          <FilterRadiology>attr(0008,0060/*modality*/@series)="MR"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Evaluator" RelOP="NA">equals(Evaluators.SeriesTypeEvaluator.ProstateT2SeriesEvaluator(),true)</Requires>
              <Requires RuleType="Evaluator" RelOP="And">equals(Evaluators.SeriesTypeEvaluator.AxialPlaneEvaluator(),true)</Requires>
            </Rule>
          </Rules>
        </SeriesType>'

        /*6 = ProstateT2Coronal*/
    DECLARE @6SeriesTypeFromDBName AS NVARCHAR(32) = @prefix + 'ProstateT2Coronal'
    DECLARE @6SeriesTypeFromDBXML AS XML = '<SeriesType ID="6" Name="' + @prefix + 'ProstateT2Coronal" Description="Care Advisor Prostate MR T2 Coronal">
          <FilterRadiology>attr(0008,0060/*modality*/@series)="MR"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Evaluator" RelOP="NA">equals(Evaluators.SeriesTypeEvaluator.ProstateT2SeriesEvaluator(),true)</Requires>
              <Requires RuleType="Evaluator" RelOP="And">equals(Evaluators.SeriesTypeEvaluator.CoronalPlaneEvaluator(),true)</Requires>
              <Requires RuleType="Radiology" RelOP="Or">contains(translate(attr(0008,103E/*series description*/@series), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "t2")</Requires>
              <Requires RuleType="Radiology" RelOP="And">contains(translate(attr(0008,103E/*series description*/@series), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "cor")</Requires>
            </Rule>
          </Rules>
        </SeriesType>'

        /*7 = ProstateT2Sagittal*/
    DECLARE @7SeriesTypeFromDBName AS NVARCHAR(32) = @prefix + 'ProstateT2Sagittal'
    DECLARE @7SeriesTypeFromDBXML AS XML = '<SeriesType ID="7" Name="' + @prefix + 'ProstateT2Sagittal" Description="Care Advisor Prostate MR T2 Sagittal">
          <FilterRadiology>attr(0008,0060/*modality*/@series)="MR"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Evaluator" RelOP="NA">equals(Evaluators.SeriesTypeEvaluator.ProstateT2SeriesEvaluator(),true)</Requires>
              <Requires RuleType="Evaluator" RelOP="And">equals(Evaluators.SeriesTypeEvaluator.SagittalPlaneEvaluator(),true)</Requires>
              <Requires RuleType="Radiology" RelOP="Or">contains(translate(attr(0008,103E/*series description*/@series), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "t2")</Requires>
              <Requires RuleType="Radiology" RelOP="And">contains(translate(attr(0008,103E/*series description*/@series), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "sag")</Requires>
            </Rule>
          </Rules>
        </SeriesType>'

        /*8 = ProstateADCSeries*/
    DECLARE @8SeriesTypeFromDBName AS NVARCHAR(32) = @prefix + 'ProstateADCSeries'
    DECLARE @8SeriesTypeFromDBXML AS XML = '<SeriesType ID="8" Name="' + @prefix + 'ProstateADCSeries" Description="Care Advisor Prostate MR ADC">
          <FilterRadiology>attr(0008,0060/*modality*/@series)="MR"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Evaluator" RelOP="NA">equals(Evaluators.SeriesTypeEvaluator.ProstateADCSeriesEvaluator(),true)</Requires>
              <Requires RuleType="Radiology" RelOP="Or">contains(translate(attr(0008,103E/*series description*/@series), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "adc")</Requires>
            </Rule>
          </Rules>
        </SeriesType>'

        /*9 = ProstateDCESeries*/
    DECLARE @9SeriesTypeFromDBName AS NVARCHAR(32) = @prefix + 'ProstateDCESeries'
    DECLARE @9SeriesTypeFromDBXML AS XML = '<SeriesType ID="9" Name="' + @prefix + 'ProstateDCESeries" Description="Care Advisor Prostate MR DCE">
          <FilterRadiology>attr(0008,0060/*modality*/@series)="MR"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Evaluator" RelOP="NA">equals(Evaluators.SeriesTypeEvaluator.ProstateDCESeriesEvaluator(),true)</Requires>
              <Requires RuleType="Radiology" RelOP="Or">contains(translate(attr(0008,103E/*series description*/@series), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "dce")</Requires>
            </Rule>
          </Rules>
        </SeriesType>'

        /*10 = ProstateDWISeries*/
    DECLARE @10SeriesTypeFromDBName AS NVARCHAR(32) = @prefix + 'ProstateDWISeries'
    DECLARE @10SeriesTypeFromDBXML AS XML = '<SeriesType ID="10" Name="' + @prefix + 'ProstateDWISeries" Description="Care Advisor Prostate MR DWI">
          <FilterRadiology>attr(0008,0060/*modality*/@series)="MR"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Evaluator" RelOP="NA">equals(Evaluators.SeriesTypeEvaluator.ProstateDWISeriesEvaluator(),true)</Requires>
              <Requires RuleType="Radiology" RelOP="Or">contains(translate(attr(0008,103E/*series description*/@series), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "dwi")</Requires>
            </Rule>
          </Rules>
        </SeriesType>'

        /*11 = ProstateT1Axial*/
    DECLARE @11SeriesTypeFromDBName AS NVARCHAR(32) = @prefix + 'ProstateT1Axial'
    DECLARE @11SeriesTypeFromDBXML AS XML = '<SeriesType ID="11" Name="' + @prefix + 'ProstateT1Axial" Description="Care Advisor Prostate MR T1 Axial">
          <FilterRadiology>attr(0008,0060/*modality*/@series)="MR"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Evaluator" RelOP="NA">equals(Evaluators.SeriesTypeEvaluator.ProstateT1SeriesEvaluator(),true)</Requires>
              <Requires RuleType="Evaluator" RelOP="And">equals(Evaluators.SeriesTypeEvaluator.AxialPlaneEvaluator(),true)</Requires>
              <Requires RuleType="Radiology" RelOP="Or">contains(translate(attr(0008,103E/*series description*/@series), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "t1")</Requires>
              <Requires RuleType="Radiology" RelOP="And">contains(translate(attr(0008,103E/*series description*/@series), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "ax")</Requires>
            </Rule>
          </Rules>
        </SeriesType>'
        /*12 = LiverAIStatusSeries*/
    DECLARE @12SeriesTypeFromDBName AS NVARCHAR(32) = @prefix + 'LiverAIStatusSeries'
    DECLARE @12SeriesTypeFromDBXML AS XML = '<SeriesType ID="12" Name="' + @prefix + 'LiverAIStatusSeries" Description="Care Advisor Liver Pending AI">
          <FilterRadiology>attr(0008,0060/*modality*/@series)="MR"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Evaluator" RelOP="NA">equals(Evaluators.SeriesTypeEvaluator.LiverAdvisorAIStatusEvaluator(),true)</Requires>
            </Rule>
          </Rules>
        </SeriesType>'
        /*13 = ProstateAIStatusSeries*/
    DECLARE @13SeriesTypeFromDBName AS NVARCHAR(32) = @prefix + 'ProstateAIStatusSeries'
    DECLARE @13SeriesTypeFromDBXML AS XML = '<SeriesType ID="13" Name="' + @prefix + 'ProstateAIStatusSeries" Description="Care Advisor Prostate MR Pending AI">
          <FilterRadiology>attr(0008,0060/*modality*/@series)="MR"</FilterRadiology>
          <Rules>
            <Rule>
              <Requires RuleType="Evaluator" RelOP="NA">equals(Evaluators.SeriesTypeEvaluator.ProstateAdvisorAIStatusEvaluator(),true)</Requires>
            </Rule>
          </Rules>
        </SeriesType>'
    DECLARE @1StepFromDBName AS NVARCHAR(32) = @prefix + 'MPR4:1_step'
    DECLARE @1StepFroMDBXML AS XML = '<StepType ID="1" Name="' + @prefix + 'MPR4:1_step" ListID="DisplayID3">
        <ViewPorts3D SmartViewID="MPR4:1" SeriesType="' + @prefix + 'LiverArterialPhase" Start2DStep=""/>
          <ApplicationSettings>
            <ActiveTool>pan</ActiveTool>
            <ThumbnailBar>0</ThumbnailBar>
            <LocalizerLines>1</LocalizerLines>
          </ApplicationSettings>
          <ImageProperties>
            <ImageProperty SeriesTypes="' + @prefix + 'LiverArterialPhase">
              <WWWLPreset>110,60</WWWLPreset>
            </ImageProperty>
          </ImageProperties>
        </StepType>'
    DECLARE @2StepFromDBName AS NVARCHAR(32) = @prefix + '3D6:1_step'
    DECLARE @2StepFroMDBXML AS XML = '<StepType ID="2" Name="' + @prefix + '3D6:1_step" ListID="DisplayID2">
        <ViewPorts3D SmartViewID="3D6:1" SeriesType="' + @prefix + 'LiverVenousPhase" Start2DStep=""/>
        <ApplicationSettings>
            <ActiveTool>magnifier2</ActiveTool>
            <LinkedScrolling>1</LinkedScrolling>
            <LocalizerLines>1</LocalizerLines>
          </ApplicationSettings>
          <ImageProperties>
            <ImageProperty SeriesTypes="' + @prefix + 'LiverVenousPhase">
              <WWWLPreset>500,30</WWWLPreset>
            </ImageProperty>
          </ImageProperties>
        </StepType>'
    DECLARE @3StepFromDBName AS NVARCHAR(32) = @prefix + 'CT_LiverSinglePhase_2D'
    DECLARE @3StepFroMDBXML AS XML = '<StepType ID="3" Name="' + @prefix + 'CT_LiverSinglePhase_2D" ListID="ICA_DisplayID3">
          <Viewports SmartViewID="2D" Rows="1" Columns="1">
            <Viewport SeriesType="' + @prefix + 'LiverVenousPhase"/>
          </Viewports>
          <ApplicationSettings>
            <ActiveTool>zoom</ActiveTool>
            <ThumbnailBar>1</ThumbnailBar>
            <LocalizerLines>0</LocalizerLines>
          </ApplicationSettings>
          <ImageProperties>
            <ImageProperty SeriesTypes="' + @prefix + 'LiverPreContrastPhase">
              <WWWLPreset>150,30</WWWLPreset>
            </ImageProperty>
            <ImageProperty SeriesTypes="' + @prefix + 'LiverArterialPhase">
              <WWWLPreset>100,50</WWWLPreset>
            </ImageProperty>
            <ImageProperty SeriesTypes="' + @prefix + 'LiverVenousPhase">
              <WWWLPreset>1000,30</WWWLPreset>
            </ImageProperty>
            <ImageProperty SeriesTypes="' + @prefix + 'LiverDelayedPhase">
              <WWWLPreset>200,50</WWWLPreset>
            </ImageProperty>
          </ImageProperties>
        </StepType>'
    DECLARE @4StepFromDBName AS NVARCHAR(32) = @prefix + 'CT_LiverMultiPhase_2D'
    DECLARE @4StepFroMDBXML AS XML = '<StepType Name="' + @prefix + 'CT_LiverMultiPhase_2D" ListID="' + @prefix + 'ICA_DisplayID4">
          <Viewports SmartViewID="2D" Rows="2" Columns="2">
            <Viewport SeriesType="' + @prefix + 'LiverPreContrastPhase"></Viewport>
            <Viewport SeriesType="' + @prefix + 'LiverArterialPhase"></Viewport>
            <Viewport SeriesType="' + @prefix + 'LiverVenousPhase"></Viewport>
            <Viewport SeriesType="' + @prefix + 'LiverDelayedPhase"></Viewport>
          </Viewports>
          <ApplicationSettings>
            <ActiveTool>zoom</ActiveTool>
            <ThumbnailBar>1</ThumbnailBar>
            <LocalizerLines>0</LocalizerLines>
          </ApplicationSettings>
          <ImageProperties>
            <ImageProperty SeriesTypes="' + @prefix + 'LiverPreContrastPhase">
              <WWWLPreset>150,30</WWWLPreset>
            </ImageProperty>
            <ImageProperty SeriesTypes="' + @prefix + 'LiverArterialPhase">
              <WWWLPreset>100,50</WWWLPreset>
            </ImageProperty>
            <ImageProperty SeriesTypes="' + @prefix + 'LiverVenousPhase">
              <WWWLPreset>1000,30</WWWLPreset>
            </ImageProperty>
            <ImageProperty SeriesTypes="' + @prefix + 'LiverDelayedPhase">
              <WWWLPreset>200,50</WWWLPreset>
            </ImageProperty>
          </ImageProperties>
        </StepType>'
    DECLARE @5StepFromDBName AS NVARCHAR(32) = @prefix + 'Step_CT_LiverMultiPhase_2'
    DECLARE @5StepFroMDBXML AS XML = '<StepType  ID="5" Name="' + @prefix + 'Step_CT_LiverMultiPhase_2" ListID="' + @prefix + 'ICA_DisplayID5">
          <Viewports SmartViewID="2D" Rows="2" Columns="2">
            <Viewport SeriesType="' + @prefix + 'LiverPreContrastPhase"></Viewport>
            <Viewport SeriesType="' + @prefix + 'LiverArterialPhase"></Viewport>
            <Viewport SeriesType="' + @prefix + 'LiverVenousPhase"></Viewport>
            <Viewport SeriesType="' + @prefix + 'LiverDelayedPhase"></Viewport>
          </Viewports>
          <ApplicationSettings>
            <ActiveTool>zoom</ActiveTool>
            <ThumbnailBar>1</ThumbnailBar>
            <LocalizerLines>0</LocalizerLines>
          </ApplicationSettings>
          <ImageProperties>
          <ImageProperty SeriesTypes="' + @prefix + 'LiverPreContrastPhase">
              <WWWLPreset>150,30</WWWLPreset>
            </ImageProperty>
            <ImageProperty SeriesTypes="' + @prefix + 'LiverArterialPhase">
              <WWWLPreset>100,50</WWWLPreset>
            </ImageProperty>
            <ImageProperty SeriesTypes="' + @prefix + 'LiverVenousPhase">
              <WWWLPreset>1000,30</WWWLPreset>
            </ImageProperty>
            <ImageProperty SeriesTypes="' + @prefix + 'LiverDelayedPhase">
              <WWWLPreset>200,50</WWWLPreset>
            </ImageProperty>
          </ImageProperties>
        </StepType>'
    DECLARE @6StepFromDBName AS NVARCHAR(32) = @prefix + 'MR_Prostate_2D'
    DECLARE @6StepFroMDBXML AS XML = '<StepType ID="6" Name="' + @prefix + 'MR_Prostate_2D" ListID="' + @prefix + '2DProstateSimple">
          <Viewports SmartViewID="2D" Rows="2" Columns="2">
            <Viewport SeriesType="' + @prefix + 'ProstateT2Axial"></Viewport>
            <Viewport SeriesType="' + @prefix + 'ProstateT2Coronal"></Viewport>
            <Viewport SeriesType="' + @prefix + 'ProstateT2Sagittal"></Viewport>
            <Viewport SeriesType="' + @prefix + 'ProstateADCSeries"></Viewport>
          </Viewports>
          <ApplicationSettings>
            <ActiveTool>wl</ActiveTool>
          </ApplicationSettings>
        </StepType>'
    DECLARE @7StepFromDBName AS NVARCHAR(32) = @prefix + 'MR_Prostate_3D'
    DECLARE @7StepFroMDBXML AS XML = '<StepType ID="7" Name="' + @prefix + 'MR_Prostate_3D" ListID="' + @prefix + '3DProstateMPR">
        <ViewPorts3D SmartViewID="PROSTATE_MPR" SeriesType="' + @prefix + 'ProstateT2Axial" Start2DStep=""/>
        </StepType>'

    DECLARE @1HPName AS NVARCHAR(32) = @prefix + 'CT_LiverSinglePhase_HP'
    DECLARE @1HPXML AS XML = '<HangingProtocol ID="1" Name="' + @prefix + 'CT_LiverSinglePhase_HP" Description="Care Advisor Liver CT Single Phase">
          <StudyTypes>
            <StudyType>' + @prefix + 'CT_LiverSinglePhase_Study</StudyType>
          </StudyTypes>
          <RelevantPriors Count="4"><SelectionCriteria></SelectionCriteria></RelevantPriors>
          <Steps>
             <Step StepType="' + @prefix + 'CT_LiverSinglePhase_2D" UseFor="Both"/>
          </Steps>
        </HangingProtocol>'

    DECLARE @2HPName AS NVARCHAR(32) = @prefix + 'CT_LiverMultiPhase_HP'
    DECLARE @2HPXML AS XML = '<HangingProtocol ID="2" Name="' + @prefix + 'CT_LiverMultiPhase_HP" Description="Care Advisor Liver CT Multi Phase">
          <StudyTypes>
            <StudyType>' + @prefix + 'CT_LiverMultiPhase_Study</StudyType>
          </StudyTypes>
          <RelevantPriors Count="4"><SelectionCriteria></SelectionCriteria></RelevantPriors>
          <Steps>
            <Step StepType="' + @prefix + 'CT_LiverMultiPhase_2D" UseFor="Both"/>
          </Steps>
        </HangingProtocol>'
    DECLARE @3HPName AS NVARCHAR(32) = @prefix + 'CR_General_HP'
    DECLARE @3HPXML AS XML = '<HangingProtocol ID="3" Name="' + @prefix + 'CR_General_HP" Description="CR Generic">
          <StudyTypes>
            <StudyType>' + @prefix + 'CR_General_Study</StudyType>
          </StudyTypes>
          <RelevantPriors Count="4"><SelectionCriteria></SelectionCriteria></RelevantPriors>
        </HangingProtocol>'
    DECLARE @4HPName AS NVARCHAR(32) = @prefix + 'CT_General_HP'
    DECLARE @4HPXML AS XML = '<HangingProtocol ID="4" Name="' + @prefix + 'CT_General_HP" Description="CT Generic">
          <StudyTypes>
            <StudyType>' + @prefix + 'CT_General_Study</StudyType>
          </StudyTypes>
          <RelevantPriors Count="3"><SelectionCriteria></SelectionCriteria></RelevantPriors>
          <Steps>
            <Step StepType="CT_General_Step" UseFor="Both"/>
          </Steps>
        </HangingProtocol>'
    DECLARE @5HPName AS NVARCHAR(32) = @prefix + 'MR_General_HP'
    DECLARE @5HPXML AS XML = '<HangingProtocol ID="5" Name="' + @prefix + 'MR_General_HP" Description="MR Generic">
          <StudyTypes>
            <StudyType>' + @prefix + 'MR_General_Study</StudyType>
          </StudyTypes>
          <RelevantPriors Count="4"><SelectionCriteria></SelectionCriteria></RelevantPriors>
        </HangingProtocol>'
    DECLARE @6HPName AS NVARCHAR(32) = @prefix + 'PT_General_HP'
    DECLARE @6HPXML AS XML = '<HangingProtocol ID="6" Name="' + @prefix + 'PT_General_HP" Description="PT Generic">
          <StudyTypes>
            <StudyType>' + @prefix + 'PT_General_Study</StudyType>
          </StudyTypes>
          <RelevantPriors Count="4"><SelectionCriteria></SelectionCriteria></RelevantPriors>
        </HangingProtocol>'
    DECLARE @7HPName AS NVARCHAR(32) = @prefix + 'XA_General_HP'
    DECLARE @7HPXML AS XML = '<HangingProtocol ID="7" Name="' + @prefix + 'XA_General_HP" Description="XA Generic">
          <StudyTypes>
            <StudyType>' + @prefix + 'XA_General_Study</StudyType>
          </StudyTypes>
          <RelevantPriors Count="4"><SelectionCriteria></SelectionCriteria></RelevantPriors>
        </HangingProtocol>'
    DECLARE @8HPName AS NVARCHAR(32) = @prefix + 'US_General_HP'
    DECLARE @8HPXML AS XML = '<HangingProtocol ID="8" Name="' + @prefix + 'US_General_HP" Description="US Generic">
          <StudyTypes>
            <StudyType>' + @prefix + 'US_General_Study</StudyType>
          </StudyTypes>
        </HangingProtocol>'
    DECLARE @9HPName AS NVARCHAR(32) = @prefix + 'CT_Liver3D_HP'
    DECLARE @9HPXML AS XML = '  <HangingProtocol ID="9" Name="' + @prefix + 'CT_Liver3D_HP" Description="Care Advisor Liver CT 3D">
          <StudyTypes>
            <StudyType>' + @prefix + 'CT_LiverMultiPhase_Study</StudyType>
            <StudyType>' + @prefix + 'CT_General_Study</StudyType>
          </StudyTypes>
          <Steps>
            <Step StepType="' + @prefix + 'MPR4:1_step" UseFor="PrimaryOnly" />
            <Step StepType="' + @prefix + '3D6:1_step" UseFor="PrimaryOnly" />
            <Step StepType="' + @prefix + 'Step_CT_LiverMultiPhase_2" UseFor="Both" />
          </Steps>
          <RelevantPriors Count="2">
           <SelectionCriteria></SelectionCriteria>
          </RelevantPriors>
          <MinimumMonitorCount>4</MinimumMonitorCount>
        </HangingProtocol>'
    DECLARE @10HPName AS NVARCHAR(32) = @prefix + 'MR_Prostate_HP'
    DECLARE @10HPXML AS XML = '  <HangingProtocol ID="10" Name="' + @prefix + 'MR_Prostate_HP" Description="Care Advisor Prostate MR">
          <StudyTypes>
            <StudyType>' + @prefix + 'MR_Prostate_CAPR_Study</StudyType>
          </StudyTypes>
          <RelevantPriors Count="4"><SelectionCriteria></SelectionCriteria></RelevantPriors>
          <Steps>
            <Step StepType="' + @prefix + 'MR_Prostate_3D" UseFor="Both" />
            <Step StepType="' + @prefix + 'MR_Prostate_2D" UseFor="PrimaryOnly" />
          </Steps>
        </HangingProtocol>'


    DECLARE @StudyTypeNextAvailableID AS INT /* should be a smarter way to do this - can query table for the max value */
    DECLARE @SeriesTypeNextAvailableID AS INT /*= 9  should be a smarter way to do this - can query table for the max value */
    DECLARE @StepsNextAvailableID AS INT /*= 7  should be a smarter way to do this - can query table for the max value */
    DECLARE @HPNextAvailableID AS INT /* should be a smarter way to do this - can query table for the max value */
    SELECT @StudyTypeNextAvailableID = max([StudyTypeUid]) FROM [HangingProtocolStudyType]
    SELECT @SeriesTypeNextAvailableID = max([SeriesTypeUid]) FROM [IRWSDB].[dbo].[HangingProtocolSeriesType]
    SELECT @StepsNextAvailableID = max([HangingProtocolStepUid]) FROM [IRWSDB].[dbo].[HangingProtocolStep]
    SELECT @HPNextAvailableID = max([HangingProtocolUid]) FROM [IRWSDB].[dbo].[HangingProtocol]

    DECLARE @StudyTypeName AS NVARCHAR(32)
    DECLARE @StudyTypeXML AS XML
    DECLARE @SeriesTypeName AS NVARCHAR(32)
    DECLARE @SeriesTypeXML AS XML
    DECLARE @StepName AS NVARCHAR(32)
    DECLARE @StepXML AS XML
    DECLARE @HPName AS NVARCHAR(32)
    DECLARE @HPXML AS XML

    /*StudyType - 1 */
    SET @StudyTypeNextAvailableID = @StudyTypeNextAvailableID + 1
    SET @StudyTypeName =@1FromDBName
    SET @StudyTypeXML = @1FromDBXML
    SET @StudyTypeXML = REPLACE(CAST( @StudyTypeXML AS NVARCHAR(MAX)), 'ID="1"', 'ID="' + CAST(@StudyTypeNextAvailableID as VARCHAR(5)) + '"')
    SET IDENTITY_INSERT [HangingProtocolStudyType] ON;

    DELETE FROM [HangingProtocolStudyType] WHERE [StudyTypeName] = @StudyTypeName AND [DomainID] = @DomainID;
    INSERT INTO [HangingProtocolStudyType] (StudyTypeUid, StudyTypeName, DisplayName, StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@StudyTypeNextAvailableID,@StudyTypeName,@StudyTypeName,@StudyTypeXML,@CreationType,@AccessType,@DomainID, @UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP);

    /*StudyType - 2 */
    SET @StudyTypeNextAvailableID = @StudyTypeNextAvailableID + 1
    SET @StudyTypeName =@2FromDBName
    SET @StudyTypeXML = @2FromDBXML
    SET @StudyTypeXML = REPLACE(CAST( @StudyTypeXML AS NVARCHAR(MAX)), 'ID="2"', 'ID="' + CAST(@StudyTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolStudyType] WHERE [StudyTypeName] = @StudyTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolStudyType] (StudyTypeUid, StudyTypeName, DisplayName,StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@StudyTypeNextAvailableID,@StudyTypeName,@StudyTypeName,@StudyTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*StudyType - 3 */
    SET @StudyTypeNextAvailableID = @StudyTypeNextAvailableID + 1
    SET @StudyTypeName =@3FromDBName
    SET @StudyTypeXML = @3FromDBXML
    SET @StudyTypeXML = REPLACE(CAST( @StudyTypeXML AS NVARCHAR(MAX)), 'ID="3"', 'ID="' + CAST(@StudyTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolStudyType] WHERE [StudyTypeName] = @StudyTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolStudyType] (StudyTypeUid, StudyTypeName, DisplayName,StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@StudyTypeNextAvailableID,@StudyTypeName,@StudyTypeName,@StudyTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*StudyType - 4 */
    SET @StudyTypeNextAvailableID = @StudyTypeNextAvailableID + 1
    SET @StudyTypeName =@4FromDBName
    SET @StudyTypeXML = @4FromDBXML
    SET @StudyTypeXML = REPLACE(CAST( @StudyTypeXML AS NVARCHAR(MAX)), 'ID="4"', 'ID="' + CAST(@StudyTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolStudyType] WHERE [StudyTypeName] = @StudyTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolStudyType] (StudyTypeUid, StudyTypeName, DisplayName,StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@StudyTypeNextAvailableID,@StudyTypeName,@StudyTypeName,@StudyTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*StudyType - 5 */
    SET @StudyTypeNextAvailableID = @StudyTypeNextAvailableID + 1
    SET @StudyTypeName =@5FromDBName
    SET @StudyTypeXML = @5FromDBXML
    SET @StudyTypeXML = REPLACE(CAST( @StudyTypeXML AS NVARCHAR(MAX)), 'ID="5"', 'ID="' + CAST(@StudyTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolStudyType] WHERE [StudyTypeName] = @StudyTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolStudyType] (StudyTypeUid, StudyTypeName, DisplayName,StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@StudyTypeNextAvailableID,@StudyTypeName,@StudyTypeName,@StudyTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*StudyType - 6 */
    SET @StudyTypeNextAvailableID = @StudyTypeNextAvailableID + 1
    SET @StudyTypeName =@6FromDBName
    SET @StudyTypeXML = @6FromDBXML
    SET @StudyTypeXML = REPLACE(CAST( @StudyTypeXML AS NVARCHAR(MAX)), 'ID="6"', 'ID="' + CAST(@StudyTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolStudyType] WHERE [StudyTypeName] = @StudyTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolStudyType] (StudyTypeUid, StudyTypeName, DisplayName,StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@StudyTypeNextAvailableID,@StudyTypeName,@StudyTypeName,@StudyTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*StudyType - 7 */
    SET @StudyTypeNextAvailableID = @StudyTypeNextAvailableID + 1
    SET @StudyTypeName =@7FromDBName
    SET @StudyTypeXML = @7FromDBXML
    SET @StudyTypeXML = REPLACE(CAST( @StudyTypeXML AS NVARCHAR(MAX)), 'ID="7"', 'ID="' + CAST(@StudyTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolStudyType] WHERE [StudyTypeName] = @StudyTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolStudyType] (StudyTypeUid, StudyTypeName, DisplayName,StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@StudyTypeNextAvailableID,@StudyTypeName,@StudyTypeName,@StudyTypeXML,@CreationType,@AccessType,@DomainID, @UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*StudyType - 8 */
    SET @StudyTypeNextAvailableID = @StudyTypeNextAvailableID + 1
    SET @StudyTypeName =@8FromDBName
    SET @StudyTypeXML = @8FromDBXML
    SET @StudyTypeXML = REPLACE(CAST( @StudyTypeXML AS NVARCHAR(MAX)), 'ID="8"', 'ID="' + CAST(@StudyTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolStudyType] WHERE [StudyTypeName] = @StudyTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolStudyType] (StudyTypeUid, StudyTypeName, DisplayName,StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@StudyTypeNextAvailableID,@StudyTypeName,@StudyTypeName,@StudyTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*StudyType - 9 */
    SET @StudyTypeNextAvailableID = @StudyTypeNextAvailableID + 1
    SET @StudyTypeName =@9FromDBName
    SET @StudyTypeXML = @9FromDBXML
    SET @StudyTypeXML = REPLACE(CAST( @StudyTypeXML AS NVARCHAR(MAX)), 'ID="9"', 'ID="' + CAST(@StudyTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolStudyType] WHERE [StudyTypeName] = @StudyTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolStudyType] (StudyTypeUid, StudyTypeName, DisplayName,StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@StudyTypeNextAvailableID,@StudyTypeName,@StudyTypeName,@StudyTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*StudyType - 10 */
    SET @StudyTypeNextAvailableID = @StudyTypeNextAvailableID + 1
    SET @StudyTypeName =@10FromDBName
    SET @StudyTypeXML = @10FromDBXML
    SET @StudyTypeXML = REPLACE(CAST( @StudyTypeXML AS NVARCHAR(MAX)), 'ID="10"', 'ID="' + CAST(@StudyTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolStudyType] WHERE [StudyTypeName] = @StudyTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolStudyType] (StudyTypeUid, StudyTypeName, DisplayName,StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@StudyTypeNextAvailableID,@StudyTypeName,@StudyTypeName,@StudyTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*StudyType - 11 */
    SET @StudyTypeNextAvailableID = @StudyTypeNextAvailableID + 1
    SET @StudyTypeName =@11FromDBName
    SET @StudyTypeXML = @11FromDBXML
    SET @StudyTypeXML = REPLACE(CAST( @StudyTypeXML AS NVARCHAR(MAX)), 'ID="11"', 'ID="' + CAST(@StudyTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolStudyType] WHERE [StudyTypeName] = @StudyTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolStudyType] (StudyTypeUid, StudyTypeName, DisplayName,StudyTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@StudyTypeNextAvailableID,@StudyTypeName,@StudyTypeName,@StudyTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)
    SET IDENTITY_INSERT [HangingProtocolStudyType] OFF

    /*SeriesType - 1 */
    SET @SeriesTypeNextAvailableID = @SeriesTypeNextAvailableID + 1
    SET @SeriesTypeName =@1SeriesTypeFromDBName
    SET @SeriesTypeXML = @1SeriesTypeFromDBXML
    SET @SeriesTypeXML = REPLACE(CAST( @SeriesTypeXML AS NVARCHAR(MAX)), 'ID="1"', 'ID="' + CAST(@SeriesTypeNextAvailableID as VARCHAR(5)) + '"')
    SET IDENTITY_INSERT [HangingProtocolSeriesType] ON
    DELETE FROM [HangingProtocolSeriesType] WHERE [SeriesTypeName] = @SeriesTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolSeriesType] (SeriesTypeUid,SeriesTypeName, DisplayName,SeriesTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@SeriesTypeNextAvailableID,@SeriesTypeName,@SeriesTypeName,@SeriesTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*SeriesType - 2 */
    SET @SeriesTypeNextAvailableID = @SeriesTypeNextAvailableID + 1
    SET @SeriesTypeName =@2SeriesTypeFromDBName
    SET @SeriesTypeXML = @2SeriesTypeFromDBXML
    SET @SeriesTypeXML = REPLACE(CAST( @SeriesTypeXML AS NVARCHAR(MAX)), 'ID="2"', 'ID="' + CAST(@SeriesTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolSeriesType] WHERE [SeriesTypeName] = @SeriesTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolSeriesType] (SeriesTypeUid,SeriesTypeName, DisplayName,SeriesTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@SeriesTypeNextAvailableID,@SeriesTypeName,@SeriesTypeName,@SeriesTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*SeriesType - 3 */
    SET @SeriesTypeNextAvailableID = @SeriesTypeNextAvailableID + 1
    SET @SeriesTypeName =@3SeriesTypeFromDBName
    SET @SeriesTypeXML = @3SeriesTypeFromDBXML
    SET @SeriesTypeXML = REPLACE(CAST( @SeriesTypeXML AS NVARCHAR(MAX)), 'ID="3"', 'ID="' + CAST(@SeriesTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolSeriesType] WHERE [SeriesTypeName] = @SeriesTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolSeriesType] (SeriesTypeUid,SeriesTypeName, DisplayName,SeriesTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@SeriesTypeNextAvailableID,@SeriesTypeName,@SeriesTypeName,@SeriesTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*SeriesType - 4 */
    SET @SeriesTypeNextAvailableID = @SeriesTypeNextAvailableID + 1
    SET @SeriesTypeName =@4SeriesTypeFromDBName
    SET @SeriesTypeXML = @4SeriesTypeFromDBXML
    SET @SeriesTypeXML = REPLACE(CAST( @SeriesTypeXML AS NVARCHAR(MAX)), 'ID="4"', 'ID="' + CAST(@SeriesTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolSeriesType] WHERE [SeriesTypeName] = @SeriesTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolSeriesType] (SeriesTypeUid,SeriesTypeName, DisplayName,SeriesTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@SeriesTypeNextAvailableID,@SeriesTypeName,@SeriesTypeName,@SeriesTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*SeriesType - 5 */
    SET @SeriesTypeNextAvailableID = @SeriesTypeNextAvailableID + 1
    SET @SeriesTypeName =@5SeriesTypeFromDBName
    SET @SeriesTypeXML = @5SeriesTypeFromDBXML
    SET @SeriesTypeXML = REPLACE(CAST( @SeriesTypeXML AS NVARCHAR(MAX)), 'ID="5"', 'ID="' + CAST(@SeriesTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolSeriesType] WHERE [SeriesTypeName] = @SeriesTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolSeriesType] (SeriesTypeUid,SeriesTypeName, DisplayName,SeriesTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@SeriesTypeNextAvailableID,@SeriesTypeName,@SeriesTypeName,@SeriesTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*SeriesType - 6 */
    SET @SeriesTypeNextAvailableID = @SeriesTypeNextAvailableID + 1
    SET @SeriesTypeName =@6SeriesTypeFromDBName
    SET @SeriesTypeXML = @6SeriesTypeFromDBXML
    SET @SeriesTypeXML = REPLACE(CAST( @SeriesTypeXML AS NVARCHAR(MAX)), 'ID="6"', 'ID="' + CAST(@SeriesTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolSeriesType] WHERE [SeriesTypeName] = @SeriesTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolSeriesType] (SeriesTypeUid,SeriesTypeName, DisplayName,SeriesTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@SeriesTypeNextAvailableID,@SeriesTypeName,@SeriesTypeName,@SeriesTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*SeriesType - 7 */
    SET @SeriesTypeNextAvailableID = @SeriesTypeNextAvailableID + 1
    SET @SeriesTypeName =@7SeriesTypeFromDBName
    SET @SeriesTypeXML = @7SeriesTypeFromDBXML
    SET @SeriesTypeXML = REPLACE(CAST( @SeriesTypeXML AS NVARCHAR(MAX)), 'ID="7"', 'ID="' + CAST(@SeriesTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolSeriesType] WHERE [SeriesTypeName] = @SeriesTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolSeriesType] (SeriesTypeUid,SeriesTypeName, DisplayName,SeriesTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@SeriesTypeNextAvailableID,@SeriesTypeName,@SeriesTypeName,@SeriesTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*SeriesType - 8 */
    SET @SeriesTypeNextAvailableID = @SeriesTypeNextAvailableID + 1
    SET @SeriesTypeName =@8SeriesTypeFromDBName
    SET @SeriesTypeXML = @8SeriesTypeFromDBXML
    SET @SeriesTypeXML = REPLACE(CAST( @SeriesTypeXML AS NVARCHAR(MAX)), 'ID="8"', 'ID="' + CAST(@SeriesTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolSeriesType] WHERE [SeriesTypeName] = @SeriesTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolSeriesType] (SeriesTypeUid,SeriesTypeName, DisplayName,SeriesTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@SeriesTypeNextAvailableID,@SeriesTypeName,@SeriesTypeName,@SeriesTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*SeriesType - 9 */
    SET @SeriesTypeNextAvailableID = @SeriesTypeNextAvailableID + 1
    SET @SeriesTypeName =@9SeriesTypeFromDBName
    SET @SeriesTypeXML = @9SeriesTypeFromDBXML
    SET @SeriesTypeXML = REPLACE(CAST( @SeriesTypeXML AS NVARCHAR(MAX)), 'ID="9"', 'ID="' + CAST(@SeriesTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolSeriesType] WHERE [SeriesTypeName] = @SeriesTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolSeriesType] (SeriesTypeUid,SeriesTypeName, DisplayName,SeriesTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@SeriesTypeNextAvailableID,@SeriesTypeName,@SeriesTypeName,@SeriesTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*SeriesType - 10 */
    SET @SeriesTypeNextAvailableID = @SeriesTypeNextAvailableID + 1
    SET @SeriesTypeName =@10SeriesTypeFromDBName
    SET @SeriesTypeXML = @10SeriesTypeFromDBXML
    SET @SeriesTypeXML = REPLACE(CAST( @SeriesTypeXML AS NVARCHAR(MAX)), 'ID="10"', 'ID="' + CAST(@SeriesTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolSeriesType] WHERE [SeriesTypeName] = @SeriesTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolSeriesType] (SeriesTypeUid,SeriesTypeName, DisplayName,SeriesTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@SeriesTypeNextAvailableID,@SeriesTypeName,@SeriesTypeName,@SeriesTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*SeriesType - 11 */
    SET @SeriesTypeNextAvailableID = @SeriesTypeNextAvailableID + 1
    SET @SeriesTypeName =@11SeriesTypeFromDBName
    SET @SeriesTypeXML = @11SeriesTypeFromDBXML
    SET @SeriesTypeXML = REPLACE(CAST( @SeriesTypeXML AS NVARCHAR(MAX)), 'ID="11"', 'ID="' + CAST(@SeriesTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolSeriesType] WHERE [SeriesTypeName] = @SeriesTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolSeriesType] (SeriesTypeUid,SeriesTypeName, DisplayName,SeriesTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@SeriesTypeNextAvailableID,@SeriesTypeName,@SeriesTypeName,@SeriesTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*SeriesType - 12 */
    SET @SeriesTypeNextAvailableID = @SeriesTypeNextAvailableID + 1
    SET @SeriesTypeName =@12SeriesTypeFromDBName
    SET @SeriesTypeXML = @12SeriesTypeFromDBXML
    SET @SeriesTypeXML = REPLACE(CAST( @SeriesTypeXML AS NVARCHAR(MAX)), 'ID="12"', 'ID="' + CAST(@SeriesTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolSeriesType] WHERE [SeriesTypeName] = @SeriesTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolSeriesType] (SeriesTypeUid,SeriesTypeName, DisplayName,SeriesTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@SeriesTypeNextAvailableID,@SeriesTypeName,@SeriesTypeName,@SeriesTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /*SeriesType - 13 */
    SET @SeriesTypeNextAvailableID = @SeriesTypeNextAvailableID + 1
    SET @SeriesTypeName =@13SeriesTypeFromDBName
    SET @SeriesTypeXML = @13SeriesTypeFromDBXML
    SET @SeriesTypeXML = REPLACE(CAST( @SeriesTypeXML AS NVARCHAR(MAX)), 'ID="13"', 'ID="' + CAST(@SeriesTypeNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolSeriesType] WHERE [SeriesTypeName] = @SeriesTypeName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolSeriesType] (SeriesTypeUid,SeriesTypeName, DisplayName,SeriesTypeXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@SeriesTypeNextAvailableID,@SeriesTypeName,@SeriesTypeName,@SeriesTypeXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    SET IDENTITY_INSERT [HangingProtocolSeriesType] OFF

    SET IDENTITY_INSERT [HangingProtocol] ON
    /* HP - 1 */
    SET @HPNextAvailableID = @HPNextAvailableID + 1
    SET @HPName =@1HPName
    SET @HPXML = @1HPXML
    SET @HPXML = REPLACE(CAST( @HPXML AS NVARCHAR(MAX)), 'ID="1"', 'ID="' + CAST(@HPNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocol] WHERE [HangingProtocolName] = @HPName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocol] (HangingProtocolUid,HangingProtocolName, DisplayName,HangingProtocolXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@HPNextAvailableID,@HPName,@HPName,@HPXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    DECLARE @3StepHangingProtocolID AS INT = @HPNextAvailableID

    /* HP - 2 */
    SET @HPNextAvailableID = @HPNextAvailableID + 1
    SET @HPName =@2HPName
    SET @HPXML = @2HPXML
    SET @HPXML = REPLACE(CAST( @HPXML AS NVARCHAR(MAX)), 'ID="2"', 'ID="' + CAST(@HPNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocol] WHERE [HangingProtocolName] = @HPName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocol] (HangingProtocolUid,HangingProtocolName, DisplayName,HangingProtocolXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@HPNextAvailableID,@HPName,@HPName,@HPXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    DECLARE @4StepHangingProtocolID AS INT = @HPNextAvailableID


    /* HP - 3 */
    SET @HPNextAvailableID = @HPNextAvailableID + 1
    SET @HPName =@3HPName
    SET @HPXML = @3HPXML
    SET @HPXML = REPLACE(CAST( @HPXML AS NVARCHAR(MAX)), 'ID="3"', 'ID="' + CAST(@HPNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocol] WHERE [HangingProtocolName] = @HPName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocol] (HangingProtocolUid,HangingProtocolName, DisplayName,HangingProtocolXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@HPNextAvailableID,@HPName,@HPName,@HPXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /* HP - 4 */
    SET @HPNextAvailableID = @HPNextAvailableID + 1
    SET @HPName =@4HPName
    SET @HPXML = @4HPXML
    SET @HPXML = REPLACE(CAST( @HPXML AS NVARCHAR(MAX)), 'ID="4"', 'ID="' + CAST(@HPNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocol] WHERE [HangingProtocolName] = @HPName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocol] (HangingProtocolUid,HangingProtocolName, DisplayName,HangingProtocolXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@HPNextAvailableID,@HPName,@HPName,@HPXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /* HP - 5 */
    SET @HPNextAvailableID = @HPNextAvailableID + 1
    SET @HPName =@5HPName
    SET @HPXML = @5HPXML
    SET @HPXML = REPLACE(CAST( @HPXML AS NVARCHAR(MAX)), 'ID="5"', 'ID="' + CAST(@HPNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocol] WHERE [HangingProtocolName] = @HPName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocol] (HangingProtocolUid,HangingProtocolName, DisplayName,HangingProtocolXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@HPNextAvailableID,@HPName,@HPName,@HPXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /* HP - 6 */
    SET @HPNextAvailableID = @HPNextAvailableID + 1
    SET @HPName =@6HPName
    SET @HPXML = @6HPXML
    SET @HPXML = REPLACE(CAST( @HPXML AS NVARCHAR(MAX)), 'ID="6"', 'ID="' + CAST(@HPNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocol] WHERE [HangingProtocolName] = @HPName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocol] (HangingProtocolUid,HangingProtocolName, DisplayName,HangingProtocolXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@HPNextAvailableID,@HPName,@HPName,@HPXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /* HP - 7 */
    SET @HPNextAvailableID = @HPNextAvailableID + 1
    SET @HPName =@7HPName
    SET @HPXML = @7HPXML
    SET @HPXML = REPLACE(CAST( @HPXML AS NVARCHAR(MAX)), 'ID="7"', 'ID="' + CAST(@HPNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocol] WHERE [HangingProtocolName] = @HPName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocol] (HangingProtocolUid,HangingProtocolName, DisplayName,HangingProtocolXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@HPNextAvailableID,@HPName,@HPName,@HPXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /* HP - 8 */
    SET @HPNextAvailableID = @HPNextAvailableID + 1
    SET @HPName =@8HPName
    SET @HPXML = @8HPXML
    SET @HPXML = REPLACE(CAST( @HPXML AS NVARCHAR(MAX)), 'ID="8"', 'ID="' + CAST(@HPNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocol] WHERE [HangingProtocolName] = @HPName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocol] (HangingProtocolUid,HangingProtocolName, DisplayName,HangingProtocolXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@HPNextAvailableID,@HPName,@HPName,@HPXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    /* HP - 9 */
    SET @HPNextAvailableID = @HPNextAvailableID + 1
    SET @HPName =@9HPName
    SET @HPXML = @9HPXML
    SET @HPXML = REPLACE(CAST( @HPXML AS NVARCHAR(MAX)), 'ID="9"', 'ID="' + CAST(@HPNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocol] WHERE [HangingProtocolName] = @HPName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocol] (HangingProtocolUid,HangingProtocolName, DisplayName,HangingProtocolXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@HPNextAvailableID,@HPName,@HPName,@HPXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    DECLARE @1StepHangingProtocolID AS INT = @HPNextAvailableID
    DECLARE @2StepHangingProtocolID AS INT = @HPNextAvailableID
    DECLARE @5StepHangingProtocolID AS INT = @HPNextAvailableID

    /* HP - 10 */
    SET @HPNextAvailableID = @HPNextAvailableID + 1
    SET @HPName =@10HPName
    SET @HPXML = @10HPXML
    SET @HPXML = REPLACE(CAST( @HPXML AS NVARCHAR(MAX)), 'ID="10"', 'ID="' + CAST(@HPNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocol] WHERE [HangingProtocolName] = @HPName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocol] (HangingProtocolUid,HangingProtocolName, DisplayName,HangingProtocolXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime)
    VALUES (@HPNextAvailableID,@HPName,@HPName,@HPXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

    DECLARE @7StepHangingProtocolID AS INT = @HPNextAvailableID
    DECLARE @6StepHangingProtocolID AS INT = @HPNextAvailableID

    SET IDENTITY_INSERT [HangingProtocol] OFF

    SET IDENTITY_INSERT [HangingProtocolStep] ON
    /* Step - 1 */
    SET @StepsNextAvailableID = @StepsNextAvailableID + 1
    SET @StepName =@1StepFromDBName
    SET @StepXML = @1StepFroMDBXML
    SET @StepXML = REPLACE(CAST( @StepXML AS NVARCHAR(MAX)), 'ID="1"', 'ID="' + CAST(@StepsNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolStep] WHERE [HangingProtocolStepName] = @StepName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolStep] (HangingProtocolStepUid,HangingProtocolStepName, HangingProtocolStepXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime,HangingProtocolID)
    VALUES (@StepsNextAvailableID,@StepName,@StepXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,@1StepHangingProtocolID)

    /* Step - 2 */
    SET @StepsNextAvailableID = @StepsNextAvailableID + 1
    SET @StepName =@2StepFromDBName
    SET @StepXML = @2StepFroMDBXML
    SET @StepXML = REPLACE(CAST( @StepXML AS NVARCHAR(MAX)), 'ID="2"', 'ID="' + CAST(@StepsNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolStep] WHERE [HangingProtocolStepName] = @StepName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolStep] (HangingProtocolStepUid,HangingProtocolStepName, HangingProtocolStepXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime,HangingProtocolID)
    VALUES (@StepsNextAvailableID,@StepName,@StepXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,@2StepHangingProtocolID)

    /* Step - 3 */
    SET @StepsNextAvailableID = @StepsNextAvailableID + 1
    SET @StepName =@3StepFromDBName
    SET @StepXML = @3StepFroMDBXML
    SET @StepXML = REPLACE(CAST( @StepXML AS NVARCHAR(MAX)), 'ID="3"', 'ID="' + CAST(@StepsNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolStep] WHERE [HangingProtocolStepName] = @StepName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolStep] (HangingProtocolStepUid,HangingProtocolStepName, HangingProtocolStepXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime,HangingProtocolID)
    VALUES (@StepsNextAvailableID,@StepName,@StepXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,@3StepHangingProtocolID)

    /* Step - 4 */
    SET @StepsNextAvailableID = @StepsNextAvailableID + 1
    SET @StepName =@4StepFromDBName
    SET @StepXML = @4StepFroMDBXML
    SET @StepXML = REPLACE(CAST( @StepXML AS NVARCHAR(MAX)), 'ID="4"', 'ID="' + CAST(@StepsNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolStep] WHERE [HangingProtocolStepName] = @StepName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolStep] (HangingProtocolStepUid,HangingProtocolStepName, HangingProtocolStepXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime,HangingProtocolID)
    VALUES (@StepsNextAvailableID,@StepName,@StepXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,@4StepHangingProtocolID)

    /* Step - 5 */
    SET @StepsNextAvailableID = @StepsNextAvailableID + 1
    SET @StepName =@5StepFromDBName
    SET @StepXML = @5StepFroMDBXML
    SET @StepXML = REPLACE(CAST( @StepXML AS NVARCHAR(MAX)), 'ID="5"', 'ID="' + CAST(@StepsNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolStep] WHERE [HangingProtocolStepName] = @StepName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolStep] (HangingProtocolStepUid,HangingProtocolStepName, HangingProtocolStepXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime,HangingProtocolID)
    VALUES (@StepsNextAvailableID,@StepName,@StepXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,@5StepHangingProtocolID)

    /* Step - 6 */
    SET @StepsNextAvailableID = @StepsNextAvailableID + 1
    SET @StepName =@6StepFromDBName
    SET @StepXML = @6StepFroMDBXML
    SET @StepXML = REPLACE(CAST( @StepXML AS NVARCHAR(MAX)), 'ID="6"', 'ID="' + CAST(@StepsNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolStep] WHERE [HangingProtocolStepName] = @StepName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolStep] (HangingProtocolStepUid,HangingProtocolStepName, HangingProtocolStepXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime,HangingProtocolID)
    VALUES (@StepsNextAvailableID,@StepName,@StepXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,@6StepHangingProtocolID)

    /* Step - 7 */
    SET @StepsNextAvailableID = @StepsNextAvailableID + 1
    SET @StepName =@7StepFromDBName
    SET @StepXML = @7StepFroMDBXML
    SET @StepXML = REPLACE(CAST( @StepXML AS NVARCHAR(MAX)), 'ID="7"', 'ID="' + CAST(@StepsNextAvailableID as VARCHAR(5)) + '"')
    DELETE FROM [HangingProtocolStep] WHERE [HangingProtocolStepName] = @StepName AND [DomainID] = @DomainID
    INSERT INTO [HangingProtocolStep] (HangingProtocolStepUid,HangingProtocolStepName, HangingProtocolStepXml,CreationType,AccessType,DomainID,CreatedBy,CreationTime,LastModifiedTime,HangingProtocolID)
    VALUES (@StepsNextAvailableID,@StepName,@StepXML,@CreationType,@AccessType,@DomainID,@UserID,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,@7StepHangingProtocolID)
    SET IDENTITY_INSERT [HangingProtocolStep] OFF

END
GO

IF OBJECT_ID('DeleteHangingProtocolDataSet', 'p') IS NOT NULL
   DROP PROCEDURE dbo.DeleteHangingProtocolDataSet
GO

CREATE PROCEDURE dbo.DeleteHangingProtocolDataSet @prefix nvarchar(10), @DomainID nvarchar(32), @UserID nvarchar(32), @CreationType int, @AccessType int
AS
BEGIN
    /* Provide a mechanism to try to cleanup what was just created ... just incase we make a mistake */

    if (@prefix != '')
    BEGIN
        DECLARE @likePrefix NVARCHAR(32);
        SET @likePrefix = CONCAT(@prefix, '%')
        DELETE FROM [HangingProtocolStudyType] WHERE [StudyTypeName] like @likePrefix AND [DomainID] = @DomainID AND [CreatedBy] = @UserID AND [CreationType] = @CreationType AND [AccessType] = @AccessType
        DELETE FROM [HangingProtocolSeriesType] WHERE [SeriesTypeName] like @likePrefix AND [DomainID] = @DomainID AND [CreatedBy] = @UserID AND  [CreationType] = @CreationType AND [AccessType] = @AccessType
        DELETE FROM [HangingProtocolStep] WHERE [HangingProtocolStepName] like @likePrefix AND [DomainID] = @DomainID AND [CreatedBy] = @UserID AND [CreationType] = @CreationType AND [AccessType] = @AccessType
        DELETE FROM [HangingProtocol] WHERE [HangingProtocolName] like @likePrefix AND [DomainID] = @DomainID AND [CreatedBy] = @UserID AND [CreationType] = @CreationType AND [AccessType] = @AccessType
    END
    ELSE
    BEGIN
        /* Empty prefix -- just use all of the other criteria */
        DELETE FROM [HangingProtocolStudyType] WHERE [DomainID] = @DomainID AND [CreatedBy] = @UserID AND  [CreationType] = @CreationType AND [AccessType] = @AccessType
        DELETE FROM [HangingProtocolSeriesType] WHERE [DomainID] = @DomainID AND [CreatedBy] = @UserID AND  [CreationType] = @CreationType AND [AccessType] = @AccessType
        DELETE FROM [HangingProtocolStep] WHERE [DomainID] = @DomainID AND [CreatedBy] = @UserID AND  [CreationType] = @CreationType AND [AccessType] = @AccessType
        DELETE FROM [HangingProtocol] WHERE [DomainID] = @DomainID AND [CreatedBy] = @UserID AND  [CreationType] = @CreationType AND [AccessType] = @AccessType
    END
END
GO

/* Supply the 'prefix' to be applied to all HP, Series, Study and Step names to the core record set */
/* Update these values to determine which user and domain are to be modified */
DECLARE @PrefixToUse NVARCHAR(10)
DECLARE @DomainIDToUse AS NVARCHAR(32)
DECLARE @UserIDToUse AS NVARCHAR(32)
DECLARE @CreationTypeToUse AS INT /* User Defined or BuiltIn */
DECLARE @AccessTypeToUse AS INT  /* ViewProtected, Editable, ReadOnly */
/* ------------------------------------------------------------- */
/* THIS IS WHERE YOU CAN CUSTOMIZE THE CREATION OF THESE OBJECTS */
/* ------------------------------------------------------------- */
SET @DomainIDToUse = 'SuperAdminGroup' /* This refers to GroupID from AdminGroup table */
SET @UserIDToUse  = 'Administrator'    /* This refers to IRUser table */
/* ------------------------------------------------------------- */
/* ------------------------------------------------------------- */
SET @PrefixToUse = 'DEV-'
SET @CreationTypeToUse = 2             /* User Defined */
SET @AccessTypeToUse = 2               /* Editable */

EXEC CreateHangingProtocolDataSet @prefix = @PrefixToUse, @DomainID = @DomainIDToUse, @UserID = @UserIDToUse, @CreationType = @CreationTypeToUse, @AccessType = @AccessTypeToUse;

SET @PrefixToUse = 'DEV-BI'
SET @CreationTypeToUse = 1             /* BuiltIn */
SET @AccessTypeToUse = 1               /* ViewProtected */
SET @DomainIDToUse = NULL   /* No domain for built in types */

EXEC CreateHangingProtocolDataSet @prefix = @PrefixToUse, @DomainID = @DomainIDToUse, @UserID = @UserIDToUse, @CreationType = @CreationTypeToUse, @AccessType = @AccessTypeToUse;

SET @PrefixToUse = 'DEV-RO'
SET @CreationTypeToUse = 1             /* BuiltIn */
SET @AccessTypeToUse = 3               /* ReadOnly */
SET @DomainIDToUse = NULL   /* No domain for built in types */

EXEC CreateHangingProtocolDataSet @prefix = @PrefixToUse, @DomainID = @DomainIDToUse, @UserID = @UserIDToUse, @CreationType = @CreationTypeToUse, @AccessType = @AccessTypeToUse;

/* If you have a problem, you can try to back out your changes by using this call instead of the CreateHangingProtocolDataSet calls above..
EXEC DeleteHangingProtocolDataSet @prefix = @PrefixToUse, @DomainID = @DomainIDToUse, @UserID = @UserIDToUse, @CreationType = @CreationTypeToUse, @AccessType = @AccessTypeToUse;
*/


IF OBJECT_ID('CreateHangingProtocolDataSet', 'p') IS NOT NULL
   DROP PROCEDURE dbo.CreateHangingProtocolDataSet
GO

IF OBJECT_ID('DeleteHangingProtocolDataSet', 'p') IS NOT NULL
   DROP PROCEDURE dbo.DeleteHangingProtocolDataSet
GO
select * from [HangingProtocolStudyType]
select * from [HangingProtocolSeriesType]
select * from [HangingProtocolStep]
select * from [HangingProtocol]
