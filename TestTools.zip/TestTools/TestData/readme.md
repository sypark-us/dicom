# About Test Data Management for ISAM Liver Viewer

Liver Lesion panel depends on the ISAM model for exchanging data between enterprise archive and Viewer.  
This file will provide the details of currently used dataset and guidance on how to add/update new dataset.  
The major goals for these files are:
* To bring all the data sets at consolidated location
* To sync the dataset with the recent changes on the model, making developer easy to update the test data from single path
* To provide consistency on the UI wheather the data is loaded from JSON file or DICOM SR


## Types of Test Dataset
All the test data are available in the current path i.e. */iConnectAccess/Python/TestData/*.  
The controlled input test data are the ISAM json files (e.g. *IsamData.json*).  
The controlled output test data are DICOM SR files and the converted back ISAM json files from DICOM SR files.  
As per today's date, there are two set of test data:

###  PQA related data (/python/TestData/IsamData-PQA/)
This folder holds the data related for PQA testing.  
Add new set of sample PQA data to replicate various scenarios.  
We can add the subfolder if we have specific usecase or story or feature to make it more clear. 

### Dev related data (/python/TestData/IsamData-Dev/)
This folder holds the data being used by the development team for simulating various use cases.  
Add any regression test related data (.json files) in the dev path.  
If there is specific use case data for regression tests, it can be placed in the separate folders under IsamData-Dev/ with proper naming/usage description.

**Remember:** It is recommended not to put *'-output'* suffix in the input json filename, as that has been reserved for generating the same file with -output suffix in converted files.

## Generating DICOM Files
Python project contains all the test related apps under Test tools solution (Python/TestTools/TestTools.sln).  
ISAMDicomTestDataGenerator is the console application project inside same TestTools solution.  
**Steps:** 
* Put the source json files in TestData path (*/iConnectAccess/Python/TestData/*)
* Build the test solution (or, *ISAMDicomTestDataGenerator* project) which copies those test files to output bin directory (*TestTools/ISAMDicomTestDataGenerator/bin/TestData/*)
* Run the dicom generator tool from bin path (*TestTools/ISAMDicomTestDataGenerator/bin/ISAMDicomTestDataGenerator.exe*) to generate the output files.
* The output files will be named as *<originalfilename>-output suffix*.  
(For example: *IsamData6.json* will produce *IsamData6-output.json* and multiple dicom files, named as *IsamData6<studydate><studytime>.dcm* for each studies)

**Remember:** 
Please only use output files (i.e don't use input json files), as the two output files (both json and dicom) would behave identically in the ICA Viewer.  
You can also modify the configuration (*bin/ISAMDicomTestDataGenerator.exe.config*) so that input files can be placed in any other relative directory, to be read by the test tool.  
If you have any issues during conversion, you can check the logs in same path i.e. *\bin\logs* folder  

## Build Artifacts
During Jenkins build process, as part of packaging script (i.e. *Build_Package.cmd*), we copy test files and run the test tool **ISAMDicomTestDataGenerator.exe**  
The tool will generate the isam output files as in the same location as other artifacts (*/ica_python/<build#>/artifact/Python/Output_ICA/TestTools/TestData*)  
These converted files will be named with *-output* suffix.  

**Remember:** User/PQA can also download the testTools (*/artifact/Python/Output_ICA/TestTools*) and run the tool **ISAMDicomTestDataGenerator.exe** to generate any number of dicom files. 

## List of Current Files
The each folder has its own readme.md explaining detailed description of each test file(/folder).
